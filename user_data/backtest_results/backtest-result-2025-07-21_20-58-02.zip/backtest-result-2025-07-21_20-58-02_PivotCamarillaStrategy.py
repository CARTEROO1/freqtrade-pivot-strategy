from freqtrade.strategy import IStrategy, informative
from pandas import DataFrame
import talib.abstract as ta
import numpy as np
import pandas as pd

class PivotCamarillaStrategy(IStrategy):
    """
    Freqtrade strategy using Mark Fisher Pivot Range, Camarilla pivots, EMA200, and RSI.
    All pivots are calculated from the previous day's values.
    """
    INTERFACE_VERSION = 3
    timeframe = '30m'
    can_short = True
    startup_candle_count: int = 2

    # ROI, stoploss, trailing (example values)
    minimal_roi = {"0": 0.05}
    stoploss = -0.03
    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.02
    trailing_only_offset_is_reached = True

    default_leverage = 3.0

    plot_config = {
        'main_plot': {
            'd_pivot': {'color': 'fuchsia', 'type': 'scatter'},
            'd_bc': {'color': 'blue', 'type': 'scatter'},
            'd_tc': {'color': 'red', 'type': 'scatter'},
            'd_cama_h4': {'color': 'orange', 'type': 'scatter'},
            'd_cama_h3': {'color': 'orange', 'type': 'scatter'},
            'd_cama_l3': {'color': 'orange', 'type': 'scatter'},
            'd_cama_l4': {'color': 'orange', 'type': 'scatter'},
            'ema200': {'color': 'green', 'type': 'scatter'},
        },
        'subplots': {
            'RSI': {'rsi': {'color': 'purple'}},
        }
    }

    @informative('1d')
    def populate_indicators_1d(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Calculate daily pivots and Camarilla levels from 1d timeframe.
        """
        # Mark Fisher Pivot Range
        dataframe['pivot'] = (dataframe['high'] + dataframe['low'] + dataframe['close']) / 3
        dataframe['bc'] = (dataframe['high'] + dataframe['low']) / 2
        dataframe['tc'] = (dataframe['pivot'] - dataframe['bc']) + dataframe['pivot']

        # Camarilla pivots
        H = dataframe['high']
        L = dataframe['low']
        C = dataframe['close']
        dataframe['cama_h4'] = C + (H - L) * 1.1 / 2
        dataframe['cama_h3'] = C + (H - L) * 1.1 / 4
        dataframe['cama_l3'] = C - (H - L) * 1.1 / 4
        dataframe['cama_l4'] = C - (H - L) * 1.1 / 2
        return dataframe

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Merge daily pivots and Camarilla levels into 1h dataframe, calculate and forward-fill for plotting.
        """
        # Copy previous day's pivots and Camarilla levels
        for col in ['pivot', 'bc', 'tc', 'cama_h4', 'cama_h3', 'cama_l3', 'cama_l4']:
            daily_col = f'{col}_1d'
            if daily_col in dataframe.columns:
                dataframe[f'd_{col}'] = dataframe[daily_col]
            else:
                dataframe[f'd_{col}'] = np.nan

        # Forward-fill all d_ columns for plotting
        for col in ['d_pivot', 'd_bc', 'd_tc', 'd_cama_h4', 'd_cama_h3', 'd_cama_l3', 'd_cama_l4']:
            dataframe[col] = dataframe[col].ffill()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Entry logic: Buy when price crosses above d_cama_h3 (Camarilla H3 level)
        """
        dataframe['enter_long'] = (
            (dataframe['close'] > dataframe['d_cama_h3']) &
            (dataframe['close'].shift(1) <= dataframe['d_cama_h3'].shift(1))
        ).astype('int')
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Exit logic: Sell when price crosses below d_cama_l3 (Camarilla L3 level)
        """
        dataframe['exit_long'] = (
            (dataframe['close'] < dataframe['d_cama_l3']) &
            (dataframe['close'].shift(1) >= dataframe['d_cama_l3'].shift(1))
        ).astype('int')
        return dataframe

    def leverage(self, pair: str, current_time: pd.Timestamp, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: str,
                 side: str, **kwargs) -> float:
        """
        Set leverage for each trade. Adjust the return value as needed.
        """
        # Use 3x leverage, but never exceed the exchange's max
        return min(self.default_leverage, max_leverage)