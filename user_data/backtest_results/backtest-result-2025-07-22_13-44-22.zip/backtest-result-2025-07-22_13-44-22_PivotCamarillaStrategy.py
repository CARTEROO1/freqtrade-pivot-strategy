from freqtrade.strategy import IStrategy, informative
from pandas import DataFrame
import talib.abstract as ta
import numpy as np
import pandas as pd

class PivotCamarillaStrategy(IStrategy):
    """
    Freqtrade strategy using Mark Fisher Pivot Range, Camarilla pivots, EMA200, and RSI.
    All pivots are calculated from the previous day's values.
    """
    INTERFACE_VERSION = 3
    timeframe = '30m'
    startup_candle_count = 210  # Ensure enough candles for EMA200
    # Remove static stoploss and minimal_roi
    # stoploss = -0.03
    # minimal_roi = {"0": 0.05}

    plot_config = {
        'main_plot': {
            'd_pivot': {'color': 'fuchsia', 'type': 'scatter'},
            'd_bc': {'color': 'blue', 'type': 'scatter'},
            'd_tc': {'color': 'red', 'type': 'scatter'},
            'd_cama_h4': {'color': 'orange', 'type': 'scatter'},
            'd_cama_h3': {'color': 'orange', 'type': 'scatter'},
            'd_cama_l3': {'color': 'orange', 'type': 'scatter'},
            'd_cama_l4': {'color': 'orange', 'type': 'scatter'},
            'ema200': {'color': 'green', 'type': 'scatter'},
            # Add more indicators if you want
        },
        'subplots': {
            # Example: 'ATR': {'atr14': {'color': 'purple'}},
            # Example: 'Volume': {'volume': {'color': 'gray'}}
        }
    }

    @informative('1d')
    def populate_indicators_1d(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Calculate daily pivots and Camarilla levels from 1d timeframe.
        """
        # Mark Fisher Pivot Range
        dataframe['pivot'] = (dataframe['high'] + dataframe['low'] + dataframe['close']) / 3
        dataframe['bc'] = (dataframe['high'] + dataframe['low']) / 2
        dataframe['tc'] = (dataframe['pivot'] - dataframe['bc']) + dataframe['pivot']

        # Camarilla pivots
        H = dataframe['high']
        L = dataframe['low']
        C = dataframe['close']
        dataframe['cama_h4'] = C + (H - L) * 1.1 / 2
        dataframe['cama_h3'] = C + (H - L) * 1.1 / 4
        dataframe['cama_l3'] = C - (H - L) * 1.1 / 4
        dataframe['cama_l4'] = C - (H - L) * 1.1 / 2
        return dataframe

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Merge daily pivots and Camarilla levels into main timeframe, calculate EMA200, ATR, and volume filters.
        """
        dataframe = dataframe.sort_index()  # Ensure sorted by date
        # Copy previous day's pivots and Camarilla levels
        for col in ['pivot', 'bc', 'tc', 'cama_h4', 'cama_h3', 'cama_l3', 'cama_l4']:
            daily_col = f'{col}_1d'
            if daily_col in dataframe.columns:
                dataframe[f'd_{col}'] = dataframe[daily_col]
            else:
                dataframe[f'd_{col}'] = np.nan

        # Forward-fill all d_ columns for plotting
        for col in ['d_pivot', 'd_bc', 'd_tc', 'd_cama_h4', 'd_cama_h3', 'd_cama_l3', 'd_cama_l4']:
            dataframe[col] = dataframe[col].ffill()

        # Add EMA200
        dataframe['ema200'] = ta.EMA(dataframe, timeperiod=200)

        # Add ATR(14) as volatility filter
        dataframe['atr14'] = ta.ATR(dataframe, timeperiod=14)
        dataframe['atr14_mean'] = dataframe['atr14'].rolling(window=20, min_periods=1).mean()
        dataframe['volatility_filter'] = dataframe['atr14'] > dataframe['atr14_mean']

        # Add volume filter (volume above 20-period mean)
        if 'volume' in dataframe.columns:
            dataframe['volume_mean'] = dataframe['volume'].rolling(window=20, min_periods=1).mean()
            dataframe['volume_filter'] = dataframe['volume'] > dataframe['volume_mean']
        else:
            dataframe['volume_filter'] = True  # fallback if no volume data

        # Add a date column for trade counting and custom stop/roi
        dataframe['date'] = pd.to_datetime(dataframe['date'], errors='coerce') if 'date' in dataframe.columns else dataframe.index.date
        return dataframe

    def custom_stoploss(self, pair: str, trade, current_time: pd.Timestamp, current_rate: float, current_profit: float, **kwargs) -> float:
        """
        Dynamic stoploss based on ATR(14) at trade open.
        """
        dataframe = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe is None or len(dataframe) == 0:
            return 1  # fallback: no stop
        # Find the candle at trade open
        open_candle = dataframe[dataframe['date'] == trade.open_date.replace(tzinfo=None)]
        if open_candle.empty:
            return 1
        atr = open_candle['atr14'].iloc[0]
        # Set stoploss at X * ATR below entry (e.g., 1.5 ATR)
        stoploss_price = trade.open_rate - 1.5 * atr if trade.is_long else trade.open_rate + 1.5 * atr
        # Convert to relative stoploss
        if trade.is_long:
            rel_stop = (stoploss_price - trade.open_rate) / trade.open_rate
        else:
            rel_stop = (trade.open_rate - stoploss_price) / trade.open_rate
        return rel_stop

    def custom_roi(self, pair: str, trade, current_time: pd.Timestamp, current_rate: float, current_profit: float, **kwargs) -> float:
        """
        Dynamic ROI target based on ATR(14) at trade open (e.g., 2 * ATR).
        """
        dataframe = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe is None or len(dataframe) == 0:
            return 0.02  # fallback
        open_candle = dataframe[dataframe['date'] == trade.open_date.replace(tzinfo=None)]
        if open_candle.empty:
            return 0.02
        atr = open_candle['atr14'].iloc[0]
        roi_price = trade.open_rate + 2 * atr if trade.is_long else trade.open_rate - 2 * atr
        if trade.is_long:
            rel_roi = (roi_price - trade.open_rate) / trade.open_rate
        else:
            rel_roi = (trade.open_rate - roi_price) / trade.open_rate
        return rel_roi

    can_short = True

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Entry logic: Buy when price crosses above d_cama_h3 (Camarilla H3 level) with EMA200 filter, price above d_pivot, and both volatility and volume filters satisfied.
        Short when price crosses below d_cama_l3, below EMA200, below d_pivot, and both filters satisfied.
        """
        # Long entries
        entry1 = (
            (dataframe['close'] > dataframe['d_cama_h3']) &
            (dataframe['close'].shift(1) <= dataframe['d_cama_h3'].shift(1)) &
            (dataframe['close'] > dataframe['ema200']) &
            (dataframe['close'] > dataframe['d_pivot']) &
            (dataframe['volatility_filter']) &
            (dataframe['volume_filter'])
        )
        entry2 = (
            (dataframe['close'] > dataframe['ema200']) &
            (dataframe['close'] > dataframe['d_pivot']) &
            (dataframe['volatility_filter']) &
            (dataframe['volume_filter'])
        )
        dataframe['enter_long'] = (entry1 | entry2).astype('int')

        # Short entries (mirror logic)
        short1 = (
            (dataframe['close'] < dataframe['d_cama_l3']) &
            (dataframe['close'].shift(1) >= dataframe['d_cama_l3'].shift(1)) &
            (dataframe['close'] < dataframe['ema200']) &
            (dataframe['close'] < dataframe['d_pivot']) &
            (dataframe['volatility_filter']) &
            (dataframe['volume_filter'])
        )
        short2 = (
            (dataframe['close'] < dataframe['ema200']) &
            (dataframe['close'] < dataframe['d_pivot']) &
            (dataframe['volatility_filter']) &
            (dataframe['volume_filter'])
        )
        dataframe['enter_short'] = (short1 | short2).astype('int')
        return dataframe

    def custom_entry(self, pair: str, current_time: pd.Timestamp, current_rate: float, signal: dict, trade_count: int, trades: list, **kwargs) -> bool:
        """
        Custom entry logic to strictly limit to 2 trades per day per pair.
        """
        # Count trades for this pair on the current day
        today = current_time.date()
        trades_today = [t for t in trades if t.open_date.date() == today and t.pair == pair]
        if len(trades_today) >= 2:
            return False
        return signal.get('enter_long', False)

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Exit logic: Sell when price crosses below d_cama_l3 (Camarilla L3 level) or crosses below d_pivot.
        Cover short when price crosses above d_cama_h3 or above d_pivot.
        """
        exit_cama = (
            (dataframe['close'] < dataframe['d_cama_l3']) &
            (dataframe['close'].shift(1) >= dataframe['d_cama_l3'].shift(1))
        )
        exit_pivot = (
            (dataframe['close'] < dataframe['d_pivot']) &
            (dataframe['close'].shift(1) >= dataframe['d_pivot'].shift(1))
        )
        dataframe['exit_long'] = (exit_cama | exit_pivot).astype('int')

        # Short exit: price crosses above d_cama_h3 or d_pivot
        exit_cama_short = (
            (dataframe['close'] > dataframe['d_cama_h3']) &
            (dataframe['close'].shift(1) <= dataframe['d_cama_h3'].shift(1))
        )
        exit_pivot_short = (
            (dataframe['close'] > dataframe['d_pivot']) &
            (dataframe['close'].shift(1) <= dataframe['d_pivot'].shift(1))
        )
        dataframe['exit_short'] = (exit_cama_short | exit_pivot_short).astype('int')
        return dataframe

    def leverage(self, pair: str, current_time: pd.Timestamp, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: str,
                 side: str, **kwargs) -> float:
        """
        Set leverage for each trade. Adjust the return value as needed.
        """
        # Use 3x leverage, but never exceed the exchange's max
        return min(self.default_leverage, max_leverage)