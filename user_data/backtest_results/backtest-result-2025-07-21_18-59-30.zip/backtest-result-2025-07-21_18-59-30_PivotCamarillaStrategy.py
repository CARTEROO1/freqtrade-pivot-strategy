from freqtrade.strategy import IStrategy, informative
from pandas import DataFrame
import talib.abstract as ta
import numpy as np
import pandas as pd

class PivotCamarillaStrategy(IStrategy):
    """
    Freqtrade strategy using Mark Fisher Pivot Range, Camarilla pivots, EMA200, and RSI.
    All pivots are calculated from the previous day's values.
    """
    INTERFACE_VERSION = 3
    timeframe = '1h'
    can_short = True
    startup_candle_count: int = 50

    # ROI, stoploss, trailing (example values)
    minimal_roi = {"0": 0.05}
    stoploss = -0.03
    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.02
    trailing_only_offset_is_reached = True

    default_leverage = 3.0

    plot_config = {
        'main_plot': {
            'd_pivot': {'color': 'fuchsia', 'type': 'line'},
            'd_bc': {'color': 'blue', 'type': 'line'},
            'd_tc': {'color': 'red', 'type': 'line'},
            'cama_h4': {'color': 'orange', 'type': 'line'},
            'cama_h3': {'color': 'orange', 'type': 'line'},
            'cama_l3': {'color': 'orange', 'type': 'line'},
            'cama_l4': {'color': 'orange', 'type': 'line'},
            'ema200': {'color': 'green', 'type': 'line'},
        },
        'subplots': {
            'RSI': {'rsi': {'color': 'purple'}},
        }
    }

    @informative('1d')
    def populate_indicators_1d(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Calculate daily pivots and Camarilla levels from 1d timeframe.
        """
        # Mark Fisher Pivot Range
        dataframe['pivot'] = (dataframe['high'] + dataframe['low'] + dataframe['close']) / 3
        dataframe['bc'] = (dataframe['high'] + dataframe['low']) / 2
        dataframe['tc'] = (dataframe['pivot'] - dataframe['bc']) + dataframe['pivot']

        # Camarilla pivots
        H = dataframe['high']
        L = dataframe['low']
        C = dataframe['close']
        dataframe['cama_h4'] = C + (H - L) * 1.1 / 2
        dataframe['cama_h3'] = C + (H - L) * 1.1 / 4
        dataframe['cama_l3'] = C - (H - L) * 1.1 / 4
        dataframe['cama_l4'] = C - (H - L) * 1.1 / 2
        return dataframe

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Merge daily pivots and Camarilla levels into 1h dataframe, calculate EMA200 and RSI.
        """
        # Copy previous day's pivots and Camarilla levels
        for col in ['pivot', 'bc', 'tc', 'cama_h4', 'cama_h3', 'cama_l3', 'cama_l4']:
            daily_col = f'{col}_1d'
            if daily_col in dataframe.columns:
                dataframe[f'd_{col}'] = dataframe[daily_col]
            else:
                dataframe[f'd_{col}'] = np.nan

        # EMA200 and RSI
        dataframe['ema200'] = ta.EMA(dataframe, timeperiod=200)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Example entry logic:
        - Long: price above d_pivot, above ema200, RSI > 50
        - Short: price below d_pivot, below ema200, RSI < 50
        """
        dataframe['enter_long'] = (
            (dataframe['close'] > dataframe['d_pivot']) &
            (dataframe['close'] > dataframe['ema200']) &
            (dataframe['rsi'] > 50)
        ).astype('int')

        dataframe['enter_short'] = (
            (dataframe['close'] < dataframe['d_pivot']) &
            (dataframe['close'] < dataframe['ema200']) &
            (dataframe['rsi'] < 50)
        ).astype('int')
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Example exit logic:
        - Long exit: price below d_bc or RSI > 75
        - Short exit: price above d_tc or RSI < 25
        """
        dataframe['exit_long'] = (
            (dataframe['close'] < dataframe['d_bc']) |
            (dataframe['rsi'] > 75)
        ).astype('int')

        dataframe['exit_short'] = (
            (dataframe['close'] > dataframe['d_tc']) |
            (dataframe['rsi'] < 25)
        ).astype('int')
        return dataframe

    def leverage(self, pair: str, current_time: pd.Timestamp, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: str,
                 side: str, **kwargs) -> float:
        """
        Set leverage for each trade. Adjust the return value as needed.
        """
        # Use 3x leverage, but never exceed the exchange's max
        return min(self.default_leverage, max_leverage)